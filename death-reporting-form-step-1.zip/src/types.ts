export interface AlmarhumData {
  nik: string;
  namaLengkap: string;
  tanggalKematian: string;
  waktuKematian: string;
  tempatKematian: string;
  tempatPemakaman: string;
}

export interface PelaporData {
  hubungan: string;
  nik: string;
  nama: string;
  noHp: string;
  email: string;
}

export interface SaksiData {
  nikSaksi1: string;
  namaSaksi1: string;
  nikSaksi2: string;
  namaSaksi2: string;
}

export interface DokumenItem {
  key: string;
  label: string;
  required: boolean;
  fileName: string | null;
}

export interface DokumenData {
  items: DokumenItem[];
}

export const DOKUMEN_LIST: DokumenItem[] = [
  { key: "surat_kematian", label: "Surat Keterangan Kematian", required: true, fileName: null },
  { key: "formulir_f201", label: "Formulir F-2.01", required: true, fileName: null },
  { key: "ktp_almarhum", label: "KTP Almarhum", required: true, fileName: null },
  { key: "kk_almarhum", label: "KK Almarhum", required: true, fileName: null },
  { key: "ktp_pelapor", label: "KTP Pelapor", required: true, fileName: null },
  { key: "ktp_saksi_1", label: "KTP Saksi 1", required: true, fileName: null },
  { key: "ktp_saksi_2", label: "KTP Saksi 2", required: true, fileName: null },
  { key: "dokumen_pendukung", label: "Dokumen Pendukung", required: false, fileName: null },
];

export type LaporanStatus = "Baru" | "Pengajuan" | "Proses" | "Ditolak" | "Selesai";

export interface Laporan {
  id: string;
  almarhum: AlmarhumData;
  pelapor: PelaporData;
  saksi: SaksiData;
  dokumen: DokumenItem[];
  status: LaporanStatus;
  createdAt: string;
  createdAtISO: string;
}

export const emptyAlmarhum: AlmarhumData = {
  nik: "",
  namaLengkap: "",
  tanggalKematian: "",
  waktuKematian: "",
  tempatKematian: "",
  tempatPemakaman: "",
};

export const emptyPelapor: PelaporData = {
  hubungan: "",
  nik: "",
  nama: "",
  noHp: "",
  email: "",
};

export const emptySaksi: SaksiData = {
  nikSaksi1: "",
  namaSaksi1: "",
  nikSaksi2: "",
  namaSaksi2: "",
};

export type WizardStep = 1 | 2 | 3 | 4 | 5;

export type AppView = "login" | "register" | "dashboard" | "laporan" | "profil" | "wizard" | "success";
