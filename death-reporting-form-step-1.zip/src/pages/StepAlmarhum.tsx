import { useState, type ReactNode } from "react";
import Stepper from "../components/Stepper";
import type { AlmarhumData } from "../types";

interface Props {
  data: AlmarhumData;
  onNext: (data: AlmarhumData) => void;
  onBack: () => void;
}

export default function StepAlmarhum({ data, onNext, onBack }: Props) {
  const [form, setForm] = useState<AlmarhumData>(data);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = (key: keyof AlmarhumData, value: string) => setForm((f) => ({ ...f, [key]: value }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!/^\d{16}$/.test(form.nik)) e.nik = "NIK harus terdiri dari 16 digit angka.";
    if (!form.namaLengkap.trim()) e.namaLengkap = "Nama lengkap wajib diisi.";
    if (!form.tanggalKematian) e.tanggalKematian = "Tanggal kematian wajib diisi.";
    if (!form.waktuKematian) e.waktuKematian = "Waktu kematian wajib diisi.";
    if (!form.tempatKematian.trim()) e.tempatKematian = "Tempat kematian wajib diisi.";
    if (!form.tempatPemakaman.trim()) e.tempatPemakaman = "Tempat pemakaman wajib diisi.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onNext(form);
  };

  return (
    <div className="w-full max-w-[800px] mx-auto">
      <Stepper step={1} stepLabel="Data Almarhum" />

      <div className="mb-stack-lg">
        <h2 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-md md:font-headline-md text-on-surface mb-stack-sm">
          Data Almarhum
        </h2>
        <p className="text-body-md font-body-md text-on-surface-variant">
          Harap isi data almarhum/almarhumah dengan benar sesuai dengan dokumen kependudukan yang sah (KTP/KK).
        </p>
      </div>

      <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-4 sm:p-8 shadow-sm mb-stack-lg">
        <form className="flex flex-col gap-stack-md sm:gap-gutter" onSubmit={(e) => e.preventDefault()}>
          <Field
            label="Nomor Induk Kependudukan (NIK)"
            required
            error={errors.nik}
            hint="Pastikan 16 digit angka valid."
          >
            <input
              className={inputClass(!!errors.nik)}
              maxLength={16}
              value={form.nik}
              onChange={(e) => set("nik", e.target.value.replace(/\D/g, ""))}
              placeholder="16 Digit NIK"
              inputMode="numeric"
              type="text"
            />
          </Field>

          <Field label="Nama Lengkap" required error={errors.namaLengkap}>
            <input
              className={inputClass(!!errors.namaLengkap)}
              value={form.namaLengkap}
              onChange={(e) => set("namaLengkap", e.target.value)}
              placeholder="Sesuai KTP"
              type="text"
            />
          </Field>

          <Field label="Tanggal Kematian" required error={errors.tanggalKematian}>
            <div className="relative">
              <input
                className={inputClass(!!errors.tanggalKematian) + " pr-10"}
                type="date"
                value={form.tanggalKematian}
                onChange={(e) => set("tanggalKematian", e.target.value)}
              />
              <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-outline pointer-events-none">
                calendar_month
              </span>
            </div>
          </Field>

          <Field label="Waktu Kematian" required error={errors.waktuKematian}>
            <div className="relative">
              <input
                className={inputClass(!!errors.waktuKematian) + " pr-10"}
                type="time"
                value={form.waktuKematian}
                onChange={(e) => set("waktuKematian", e.target.value)}
              />
              <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-outline pointer-events-none">
                schedule
              </span>
            </div>
          </Field>

          <Field label="Tempat Kematian (Kota/Kabupaten)" required error={errors.tempatKematian}>
            <input
              className={inputClass(!!errors.tempatKematian)}
              value={form.tempatKematian}
              onChange={(e) => set("tempatKematian", e.target.value)}
              placeholder="Contoh: Kabupaten Garut"
              type="text"
            />
          </Field>

          <Field label="Tempat Pemakaman (Nama TPU)" required error={errors.tempatPemakaman}>
            <input
              className={inputClass(!!errors.tempatPemakaman)}
              value={form.tempatPemakaman}
              onChange={(e) => set("tempatPemakaman", e.target.value)}
              placeholder="Contoh: TPU Pasir Pogor"
              type="text"
            />
          </Field>
        </form>
      </div>

      <div className="flex flex-col-reverse sm:flex-row gap-4 justify-between items-center">
        <button
          type="button"
          onClick={onBack}
          className="hidden sm:block text-label-md font-label-md text-secondary border border-secondary px-6 py-2.5 rounded-full hover:bg-surface-variant transition-colors"
        >
          Kembali ke Beranda
        </button>
        <button
          type="button"
          onClick={handleSubmit}
          className="w-full sm:w-auto bg-primary text-on-primary text-label-md font-label-md px-6 py-3 rounded-full flex items-center justify-center gap-2 hover:opacity-90 transition-colors shadow-sm"
        >
          Lanjutkan
          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>
    </div>
  );
}

function inputClass(hasError: boolean) {
  return (
    "w-full bg-surface-container-lowest border rounded-lg px-4 py-3 text-body-md font-body-md text-on-surface placeholder:text-outline focus:outline-none focus:ring-1 transition-all " +
    (hasError
      ? "border-error focus:border-error focus:ring-error"
      : "border-outline focus:border-primary focus:ring-primary")
  );
}

function Field({
  label,
  required,
  error,
  hint,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-stack-sm">
      <label className="text-label-md font-label-md text-on-surface flex items-center">
        {label} {required && <span className="text-error ml-1">*</span>}
      </label>
      {children}
      {error ? (
        <span className="text-caption font-caption text-error">{error}</span>
      ) : hint ? (
        <span className="text-caption font-caption text-on-surface-variant">{hint}</span>
      ) : null}
    </div>
  );
}
