import { useState, type ReactNode } from "react";
import Stepper from "../components/Stepper";
import type { AlmarhumData, PelaporData, SaksiData, DokumenItem } from "../types";

interface Props {
  almarhum: AlmarhumData;
  pelapor: PelaporData;
  saksi: SaksiData;
  dokumen: DokumenItem[];
  onSubmit: () => void;
  onBack: () => void;
  onEditStep: (step: 1 | 2 | 3 | 4) => void;
}

const HUBUNGAN_LABEL: Record<string, string> = {
  suami_istri: "Suami/Istri",
  anak: "Anak",
  orang_tua: "Orang Tua",
  saudara: "Saudara",
  lainnya: "Lainnya",
};

function formatTanggal(tanggal: string) {
  if (!tanggal) return "-";
  try {
    return new Date(tanggal).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
  } catch {
    return tanggal;
  }
}

export default function StepKonfirmasi({ almarhum, pelapor, saksi, dokumen, onSubmit, onBack, onEditStep }: Props) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({
    almarhum: true,
    pelapor: true,
    saksi: true,
    dokumen: true,
  });
  const [agreed, setAgreed] = useState(false);
  const [showAgreeWarning, setShowAgreeWarning] = useState(false);

  const toggle = (key: string) => setExpanded((e) => ({ ...e, [key]: !e[key] }));

  const handleSubmit = () => {
    if (!agreed) {
      setShowAgreeWarning(true);
      return;
    }
    onSubmit();
  };

  return (
    <div className="w-full max-w-[1100px] mx-auto">
      <Stepper step={5} stepLabel="Konfirmasi" />

      <div className="mb-stack-lg">
        <div className="flex items-center justify-between mb-stack-sm flex-wrap gap-2">
          <h1 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-md md:font-headline-md text-on-surface">
            Konfirmasi Laporan
          </h1>
        </div>
        <p className="text-body-md font-body-md text-on-surface-variant">
          Periksa kembali seluruh data yang telah Anda masukkan sebelum mengirimkan laporan.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-gutter items-start">
        <div className="md:col-span-8 flex flex-col gap-gutter">
          <ReviewCard
            title="Data Almarhum"
            icon="personal_injury"
            iconBg="bg-error-container"
            iconColor="text-on-error-container"
            expanded={expanded.almarhum}
            onToggle={() => toggle("almarhum")}
            onEdit={() => onEditStep(1)}
          >
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-y-stack-md gap-x-8">
              <Item label="Nomor Induk Kependudukan (NIK)" value={almarhum.nik || "-"} />
              <Item label="Nama Lengkap" value={almarhum.namaLengkap || "-"} />
              <Item label="Tanggal Wafat" value={formatTanggal(almarhum.tanggalKematian)} />
              <Item label="Waktu Wafat" value={almarhum.waktuKematian ? `${almarhum.waktuKematian} WIB` : "-"} />
              <Item label="Tempat Wafat" value={almarhum.tempatKematian || "-"} span2 />
              <Item label="Tempat Pemakaman" value={almarhum.tempatPemakaman || "-"} span2 />
            </dl>
          </ReviewCard>

          <ReviewCard
            title="Data Pelapor"
            icon="record_voice_over"
            iconBg="bg-primary-fixed"
            iconColor="text-on-primary-fixed"
            expanded={expanded.pelapor}
            onToggle={() => toggle("pelapor")}
            onEdit={() => onEditStep(2)}
          >
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-y-stack-md gap-x-8">
              <Item label="Nomor Induk Kependudukan (NIK)" value={pelapor.nik || "-"} />
              <Item label="Nama Lengkap" value={pelapor.nama || "-"} />
              <Item label="Hubungan dengan Almarhum" value={HUBUNGAN_LABEL[pelapor.hubungan] ?? "-"} />
              <Item label="Nomor Telepon / WhatsApp" value={pelapor.noHp ? `+62 ${pelapor.noHp}` : "-"} />
              {pelapor.email && <Item label="Email" value={pelapor.email} span2 />}
            </dl>
          </ReviewCard>

          <ReviewCard
            title="Data Saksi"
            icon="group"
            iconBg="bg-tertiary-fixed"
            iconColor="text-on-tertiary-fixed"
            expanded={expanded.saksi}
            onToggle={() => toggle("saksi")}
            onEdit={() => onEditStep(3)}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-surface-container-low rounded-lg p-4 border border-surface-container-highest">
                <h3 className="text-label-md font-label-md text-primary mb-4 flex items-center gap-2">
                  <span className="material-symbols-outlined text-[18px]">person</span> Saksi I
                </h3>
                <dl className="flex flex-col gap-3">
                  <div>
                    <dt className="text-caption font-caption text-on-surface-variant">NIK</dt>
                    <dd className="text-body-md font-body-md text-on-surface">{saksi.nikSaksi1 || "-"}</dd>
                  </div>
                  <div>
                    <dt className="text-caption font-caption text-on-surface-variant">Nama Lengkap</dt>
                    <dd className="text-body-md font-body-md text-on-surface">{saksi.namaSaksi1 || "-"}</dd>
                  </div>
                </dl>
              </div>
              <div className="bg-surface-container-low rounded-lg p-4 border border-surface-container-highest">
                <h3 className="text-label-md font-label-md text-primary mb-4 flex items-center gap-2">
                  <span className="material-symbols-outlined text-[18px]">person</span> Saksi II
                </h3>
                <dl className="flex flex-col gap-3">
                  <div>
                    <dt className="text-caption font-caption text-on-surface-variant">NIK</dt>
                    <dd className="text-body-md font-body-md text-on-surface">{saksi.nikSaksi2 || "-"}</dd>
                  </div>
                  <div>
                    <dt className="text-caption font-caption text-on-surface-variant">Nama Lengkap</dt>
                    <dd className="text-body-md font-body-md text-on-surface">{saksi.namaSaksi2 || "-"}</dd>
                  </div>
                </dl>
              </div>
            </div>
          </ReviewCard>
        </div>

        <div className="md:col-span-4 flex flex-col gap-gutter">
          <ReviewCard
            title="Dokumen"
            icon="folder_open"
            iconBg="bg-secondary-fixed"
            iconColor="text-on-secondary-fixed"
            expanded={expanded.dokumen}
            onToggle={() => toggle("dokumen")}
            onEdit={() => onEditStep(4)}
          >
            <ul className="flex flex-col gap-4">
              {dokumen.map((d) => (
                <li key={d.key} className="flex items-start gap-3">
                  <span
                    className={
                      "material-symbols-outlined mt-0.5 " + (d.fileName ? "text-secondary" : "text-outline")
                    }
                  >
                    {d.fileName ? "check_circle" : "radio_button_unchecked"}
                  </span>
                  <div>
                    <p className="text-label-md font-label-md text-on-surface">{d.label}</p>
                    <p className="text-caption font-caption text-on-surface-variant">
                      {d.fileName ?? (d.required ? "Belum diunggah" : "Opsional - tidak diunggah")}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </ReviewCard>

          <div className="sticky top-24 bg-surface-container-lowest border border-outline-variant rounded-xl p-6 shadow-sm flex flex-col gap-4">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={agreed}
                onChange={(e) => {
                  setAgreed(e.target.checked);
                  if (e.target.checked) setShowAgreeWarning(false);
                }}
                className="mt-1 h-4 w-4 rounded border-outline text-primary focus:ring-primary"
              />
              <span className="text-caption font-caption text-on-surface-variant">
                Dengan menekan tombol di bawah, saya menyatakan bahwa data yang dilaporkan adalah benar dan dapat
                dipertanggungjawabkan sesuai hukum yang berlaku.
              </span>
            </label>
            {showAgreeWarning && (
              <p className="text-caption font-caption text-error -mt-2">
                Anda harus menyetujui pernyataan di atas terlebih dahulu.
              </p>
            )}
            <button
              type="button"
              onClick={handleSubmit}
              className="w-full bg-primary text-on-primary text-label-md font-label-md rounded-full px-6 py-3 flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
            >
              <span className="material-symbols-outlined text-[20px]">send</span>
              Kirim Laporan
            </button>
            <button
              type="button"
              onClick={onBack}
              className="w-full text-primary border border-primary bg-surface-container-lowest hover:bg-surface-container-low text-label-md font-label-md rounded-full px-6 py-3 transition-colors"
            >
              Kembali
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item({ label, value, span2 }: { label: string; value: string; span2?: boolean }) {
  return (
    <div className={span2 ? "sm:col-span-2" : ""}>
      <dt className="text-label-md font-label-md text-on-surface-variant mb-1">{label}</dt>
      <dd className="text-body-md font-body-md text-on-surface font-medium">{value}</dd>
    </div>
  );
}

function ReviewCard({
  title,
  icon,
  iconBg,
  iconColor,
  expanded,
  onToggle,
  onEdit,
  children,
}: {
  title: string;
  icon: string;
  iconBg: string;
  iconColor: string;
  expanded: boolean;
  onToggle: () => void;
  onEdit: () => void;
  children: ReactNode;
}) {
  return (
    <section className="bg-surface-container-lowest border border-outline-variant rounded-xl p-6">
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-surface-container-highest">
        <button type="button" onClick={onToggle} className="flex items-center gap-3 flex-1 text-left">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${iconBg} ${iconColor}`}>
            <span className="material-symbols-outlined icon-fill">{icon}</span>
          </div>
          <h2 className="text-title-lg font-title-lg text-on-surface">{title}</h2>
        </button>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onEdit}
            className="text-secondary text-label-md font-label-md hover:underline flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-[18px]">edit</span>
            Ubah
          </button>
          <button type="button" onClick={onToggle}>
            <span
              className="material-symbols-outlined text-on-surface-variant transition-transform"
              style={{ transform: expanded ? "rotate(0deg)" : "rotate(180deg)" }}
            >
              expand_less
            </span>
          </button>
        </div>
      </div>
      {expanded && <div>{children}</div>}
    </section>
  );
}
