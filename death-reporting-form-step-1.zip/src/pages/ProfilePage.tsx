interface Props {
  name: string;
  onLogout: () => void;
}

export default function ProfilePage({ name, onLogout }: Props) {
  return (
    <div className="max-w-[1000px] mx-auto">
      {/* Profile Header */}
      <section className="mb-stack-lg flex flex-col items-center text-center mt-4">
        <div className="relative group">
          <div className="w-32 h-32 rounded-full border-4 border-white shadow-md overflow-hidden bg-surface-container-highest flex items-center justify-center">
            <span className="material-symbols-outlined text-[64px] text-on-surface-variant">person</span>
          </div>
          <button
            type="button"
            className="absolute bottom-1 right-1 bg-primary text-on-primary p-2 rounded-full shadow-lg hover:scale-105 transition-transform"
            aria-label="Ubah foto profil"
          >
            <span className="material-symbols-outlined text-[18px]">edit</span>
          </button>
        </div>
        <h2 className="mt-stack-md text-headline-md font-headline-md text-on-surface">{name}</h2>
        <p className="text-body-md font-body-md text-on-surface-variant">Petugas RT 03/12</p>
      </section>

      {/* Informasi Pribadi */}
      <section className="mb-stack-lg">
        <div className="flex items-center gap-2 mb-stack-md">
          <span className="material-symbols-outlined text-primary">person</span>
          <h3 className="text-title-lg font-title-lg text-on-surface">Informasi Pribadi</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-4 transition-all hover:shadow-md">
            <p className="text-caption font-caption text-on-surface-variant uppercase tracking-wider mb-1">NIK</p>
            <p className="text-body-lg font-body-lg text-on-surface font-semibold">3205011234560001</p>
          </div>
          <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-4 transition-all hover:shadow-md">
            <p className="text-caption font-caption text-on-surface-variant uppercase tracking-wider mb-1">
              WhatsApp
            </p>
            <div className="flex items-center justify-between gap-2">
              <p className="text-body-lg font-body-lg text-on-surface font-semibold">+62 812-3456-7890</p>
              <span className="material-symbols-outlined text-secondary text-[18px]">verified</span>
            </div>
          </div>
          <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-4 transition-all hover:shadow-md">
            <p className="text-caption font-caption text-on-surface-variant uppercase tracking-wider mb-1">Email</p>
            <p className="text-body-lg font-body-lg text-on-surface font-semibold break-all">
              b.hermanto@mail.com
            </p>
          </div>
        </div>
      </section>

      {/* Wilayah Tugas */}
      <section className="mb-stack-lg">
        <div className="flex items-center gap-2 mb-stack-md">
          <span className="material-symbols-outlined text-primary">distance</span>
          <h3 className="text-title-lg font-title-lg text-on-surface">Wilayah Tugas</h3>
        </div>
        <div className="bg-surface-container-lowest border border-outline-variant rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-outline-variant">
            <div className="p-4 flex flex-col gap-1">
              <span className="text-caption font-caption text-on-surface-variant">Kecamatan</span>
              <span className="text-body-md font-body-md font-semibold">Tarogong Kidul</span>
            </div>
            <div className="p-4 flex flex-col gap-1">
              <span className="text-caption font-caption text-on-surface-variant">Desa/Kelurahan</span>
              <span className="text-body-md font-body-md font-semibold">Sukagalih</span>
            </div>
            <div className="p-4 flex flex-col gap-1">
              <span className="text-caption font-caption text-on-surface-variant">RT/RW</span>
              <span className="text-body-md font-body-md font-semibold">03 / 12</span>
            </div>
          </div>
        </div>
      </section>

      {/* Pengaturan & Keamanan */}
      <section className="mb-stack-lg">
        <div className="flex items-center gap-2 mb-stack-md">
          <span className="material-symbols-outlined text-primary">security</span>
          <h3 className="text-title-lg font-title-lg text-on-surface">Pengaturan &amp; Keamanan</h3>
        </div>
        <div className="flex flex-col gap-2">
          <button
            type="button"
            className="flex items-center justify-between p-4 bg-surface-container-lowest border border-outline-variant rounded-xl hover:bg-surface-container-low transition-colors text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-primary-fixed flex items-center justify-center text-primary">
                <span className="material-symbols-outlined">lock_reset</span>
              </div>
              <div>
                <p className="text-body-md font-body-md font-semibold">Ubah Password</p>
                <p className="text-caption font-caption text-on-surface-variant">Terakhir diubah 3 bulan lalu</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:translate-x-1 transition-transform">
              chevron_right
            </span>
          </button>

          <button
            type="button"
            className="flex items-center justify-between p-4 bg-surface-container-lowest border border-outline-variant rounded-xl hover:bg-surface-container-low transition-colors text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-primary-fixed flex items-center justify-center text-primary">
                <span className="material-symbols-outlined">help_center</span>
              </div>
              <div>
                <p className="text-body-md font-body-md font-semibold">Pusat Bantuan</p>
                <p className="text-caption font-caption text-on-surface-variant">
                  Panduan penggunaan dan dukungan teknis
                </p>
              </div>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:translate-x-1 transition-transform">
              chevron_right
            </span>
          </button>

          <button
            type="button"
            onClick={onLogout}
            className="mt-stack-md w-full flex items-center justify-center gap-2 p-4 bg-error-container text-on-error-container border border-error rounded-xl hover:bg-error hover:text-white transition-all duration-200 group"
          >
            <span className="material-symbols-outlined transition-transform group-hover:scale-110">logout</span>
            <span className="text-body-md font-body-md font-bold">Keluar</span>
          </button>
        </div>
      </section>

      {/* Version Info */}
      <div className="text-center py-stack-lg opacity-40">
        <p className="text-caption font-caption">PAKARTIGA v2.4.1 (Stable Build)</p>
        <p className="text-caption font-caption">© 2026 Dinas Kependudukan &amp; Pencatatan Sipil</p>
      </div>
    </div>
  );
}
