import { useRef, useState } from "react";
import Stepper from "../components/Stepper";
import { DOKUMEN_LIST, type DokumenItem } from "../types";

interface Props {
  data: DokumenItem[];
  onNext: (data: DokumenItem[]) => void;
  onBack: () => void;
}

export default function StepDokumen({ data, onNext, onBack }: Props) {
  const [items, setItems] = useState<DokumenItem[]>(data.length ? data : DOKUMEN_LIST.map((d) => ({ ...d })));
  const [error, setError] = useState<string | null>(null);
  const inputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const handleFile = (key: string, file: File | null) => {
    setItems((prev) => prev.map((it) => (it.key === key ? { ...it, fileName: file ? file.name : null } : it)));
  };

  const handleSubmit = () => {
    const missing = items.filter((it) => it.required && !it.fileName);
    if (missing.length > 0) {
      setError("Harap unggah semua dokumen wajib (bertanda *) sebelum melanjutkan.");
      return;
    }
    setError(null);
    onNext(items);
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <Stepper step={4} stepLabel="Dokumen" />

      <div className="mb-stack-lg">
        <h1 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-md md:font-headline-md text-primary mb-2">
          Upload Dokumen
        </h1>
        <p className="text-body-md font-body-md text-on-surface-variant">
          Silakan unggah dokumen-dokumen persyaratan di bawah ini. Pastikan file berformat JPG, PNG, atau PDF dengan
          ukuran maksimal 2MB per file.
        </p>
      </div>

      <div className="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-sm p-6 md:p-8">
        {error && (
          <div className="mb-6 flex items-start gap-2 bg-error-container text-on-error-container rounded-lg px-4 py-3">
            <span className="material-symbols-outlined text-[20px]">error</span>
            <p className="text-body-md font-body-md">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-gutter mb-8">
          {items.map((item, idx) => (
            <div key={item.key} className="flex flex-col gap-2">
              <label className="text-label-md font-label-md text-on-surface">
                {idx + 1}. {item.label} {item.required && <span className="text-error">*</span>}
              </label>
              <input
                ref={(el) => {
                  inputRefs.current[item.key] = el;
                }}
                type="file"
                accept=".jpg,.jpeg,.png,.pdf"
                className="hidden"
                onChange={(e) => handleFile(item.key, e.target.files?.[0] ?? null)}
              />
              <button
                type="button"
                onClick={() => inputRefs.current[item.key]?.click()}
                className={
                  "border-2 border-dashed rounded-lg p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[120px] transition-colors " +
                  (item.fileName
                    ? "border-secondary bg-secondary-container/20"
                    : "border-outline-variant hover:border-primary bg-surface-container-low hover:bg-surface-container")
                }
              >
                <span
                  className={
                    "material-symbols-outlined mb-2 " + (item.fileName ? "text-secondary" : "text-outline")
                  }
                >
                  {item.fileName ? "check_circle" : "cloud_upload"}
                </span>
                <span className="text-body-md font-body-md text-primary">
                  {item.fileName ? "Ganti File" : "Pilih File"}
                </span>
                <span className="text-caption font-caption text-on-surface-variant mt-1 truncate max-w-full px-2">
                  {item.fileName ?? (item.required ? "Belum ada file" : "Opsional")}
                </span>
              </button>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-center mt-stack-lg gap-4 pt-4 border-t border-surface-container-highest">
          <button
            type="button"
            onClick={onBack}
            className="w-full sm:w-auto px-6 py-2.5 border border-secondary text-secondary font-label-md text-label-md rounded-full hover:bg-surface-container-low transition-colors text-center order-2 sm:order-1"
          >
            Kembali
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="w-full sm:w-auto px-6 py-2.5 bg-primary text-on-primary font-label-md text-label-md rounded-full hover:opacity-90 transition-opacity text-center order-1 sm:order-2 flex items-center justify-center gap-2"
          >
            Lanjutkan
            <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
          </button>
        </div>
      </div>
    </div>
  );
}
