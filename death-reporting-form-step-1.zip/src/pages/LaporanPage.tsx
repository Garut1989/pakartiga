import { useMemo, useState } from "react";
import type { Laporan, LaporanStatus } from "../types";
import LaporanDetailModal from "../components/LaporanDetailModal";

interface Props {
  laporanList: Laporan[];
}

const STATUS_BADGE: Record<LaporanStatus, { label: string; className: string }> = {
  Baru: { label: "Draft", className: "bg-surface-variant text-on-surface-variant" },
  Pengajuan: { label: "Menunggu Verifikasi RT", className: "bg-error-container text-on-error-container" },
  Proses: { label: "Menunggu Verifikasi Desa", className: "bg-error-container text-on-error-container" },
  Ditolak: { label: "Ditolak", className: "bg-error-container text-on-error-container" },
  Selesai: { label: "Selesai", className: "bg-green-100 text-green-800" },
};

function toCSV(rows: Laporan[]) {
  const header = ["No. Tiket", "Nama Almarhum", "Tanggal Wafat", "Pelapor", "Status", "Tanggal Lapor"];
  const lines = rows.map((l) =>
    [l.id, l.almarhum.namaLengkap, l.almarhum.tanggalKematian, l.pelapor.nama, STATUS_BADGE[l.status].label, l.createdAt]
      .map((v) => `"${String(v).replace(/"/g, '""')}"`)
      .join(",")
  );
  return [header.join(","), ...lines].join("\n");
}

export default function LaporanPage({ laporanList }: Props) {
  const [dariTanggal, setDariTanggal] = useState("");
  const [sampaiTanggal, setSampaiTanggal] = useState("");
  const [appliedRange, setAppliedRange] = useState<{ dari: string; sampai: string } | null>(null);
  const [selected, setSelected] = useState<Laporan | null>(null);

  const filtered = useMemo(() => {
    if (!appliedRange || (!appliedRange.dari && !appliedRange.sampai)) return laporanList;
    return laporanList.filter((l) => {
      const created = l.createdAtISO;
      if (appliedRange.dari && created < appliedRange.dari) return false;
      if (appliedRange.sampai && created > appliedRange.sampai) return false;
      return true;
    });
  }, [laporanList, appliedRange]);

  const handleTerapkan = () => {
    setAppliedRange({ dari: dariTanggal, sampai: sampaiTanggal });
  };

  const handleDownload = () => {
    const csv = toCSV(filtered);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "laporan-pakartiga.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="mb-stack-lg mt-stack-md">
        <h1 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-lg md:font-headline-lg text-on-surface mb-1">
          Laporan
        </h1>
        <p className="text-body-md font-body-md text-on-surface-variant">
          Rekap seluruh pelaporan kematian yang telah diajukan warga RT 03 / RW 05.
        </p>
      </div>

      <div className="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-sm overflow-hidden mb-stack-lg">
        <div className="p-6 border-b border-surface-container-high bg-surface-bright flex justify-between items-center">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 w-full">
            <h3 className="text-title-lg font-title-lg text-on-surface">Pelaporan</h3>
            <div className="flex flex-col md:flex-row items-end md:items-center gap-3">
              <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                <div className="flex flex-col gap-1 flex-1 min-w-[140px]">
                  <label className="text-caption font-caption text-on-surface-variant">Dari Tanggal</label>
                  <input
                    className="bg-surface-container-low border border-outline-variant rounded-lg px-3 py-1.5 text-body-md font-body-md focus:ring-2 focus:ring-primary outline-none"
                    type="date"
                    value={dariTanggal}
                    onChange={(e) => setDariTanggal(e.target.value)}
                  />
                </div>
                <div className="flex flex-col gap-1 flex-1 min-w-[140px]">
                  <label className="text-caption font-caption text-on-surface-variant">Sampai Tanggal</label>
                  <input
                    className="bg-surface-container-low border border-outline-variant rounded-lg px-3 py-1.5 text-body-md font-body-md focus:ring-2 focus:ring-primary outline-none"
                    type="date"
                    value={sampaiTanggal}
                    onChange={(e) => setSampaiTanggal(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex flex-col md:flex-row items-stretch md:items-center gap-2 mt-auto w-full md:w-auto">
                <button
                  type="button"
                  onClick={handleTerapkan}
                  className="bg-secondary text-on-secondary px-4 py-2 rounded-full font-label-md text-label-md hover:opacity-90 transition-all active:scale-95 shadow-sm w-full md:w-auto"
                >
                  Terapkan
                </button>
                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex items-center justify-center gap-1 text-primary hover:bg-primary-fixed px-3 py-2 rounded-full transition-all active:scale-95 border border-outline-variant w-full md:w-auto"
                >
                  <span className="material-symbols-outlined text-[20px]">download</span>
                  <span className="text-label-md font-label-md">Download</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Desktop Table */}
        <div className="hidden md:block w-full overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-surface-container-high bg-surface-container-lowest">
                <th className="py-4 px-6 text-on-surface-variant text-caption font-caption uppercase tracking-wider font-semibold">
                  Nama Almarhum
                </th>
                <th className="py-4 px-6 text-on-surface-variant text-caption font-caption uppercase tracking-wider font-semibold">
                  Tanggal Wafat
                </th>
                <th className="py-4 px-6 text-on-surface-variant text-caption font-caption uppercase tracking-wider font-semibold">
                  Pelapor
                </th>
                <th className="py-4 px-6 text-on-surface-variant text-caption font-caption uppercase tracking-wider font-semibold">
                  Status
                </th>
                <th className="py-4 px-6 text-right text-on-surface-variant text-caption font-caption uppercase tracking-wider font-semibold">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody className="text-body-md font-body-md">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-10 text-center text-on-surface-variant">
                    Tidak ada laporan pada rentang tanggal ini.
                  </td>
                </tr>
              ) : (
                filtered.map((l) => {
                  const badge = STATUS_BADGE[l.status];
                  return (
                    <tr
                      key={l.id}
                      className="border-b border-surface-container-low hover:bg-surface-bright transition-colors group"
                    >
                      <td className="py-4 px-6 text-on-surface font-medium">{l.almarhum.namaLengkap}</td>
                      <td className="py-4 px-6 text-on-surface-variant">
                        {new Date(l.almarhum.tanggalKematian).toLocaleDateString("id-ID", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                        })}
                      </td>
                      <td className="py-4 px-6 text-on-surface-variant">{l.pelapor.nama}</td>
                      <td className="py-4 px-6">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-caption font-caption ${badge.className}`}
                        >
                          {badge.label}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right">
                        <button
                          type="button"
                          onClick={() => setSelected(l)}
                          className="text-primary hover:text-on-primary-fixed-variant p-2 rounded-full hover:bg-primary-fixed transition-all active:scale-90"
                          aria-label="Lihat detail"
                        >
                          <span className="material-symbols-outlined">
                            {l.status === "Baru" ? "edit" : "visibility"}
                          </span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile List */}
        <div className="md:hidden flex flex-col">
          {filtered.length === 0 ? (
            <p className="py-10 text-center text-on-surface-variant text-body-md font-body-md">
              Tidak ada laporan pada rentang tanggal ini.
            </p>
          ) : (
            filtered.map((l) => {
              const badge = STATUS_BADGE[l.status];
              return (
                <div key={l.id} className="p-4 border-b border-surface-container-low hover:bg-surface-bright transition-colors">
                  <div className="flex justify-between items-start mb-2 gap-2">
                    <h4 className="text-body-md font-body-md font-medium text-on-surface">{l.almarhum.namaLengkap}</h4>
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-caption whitespace-nowrap ${badge.className}`}
                    >
                      {badge.label}
                    </span>
                  </div>
                  <p className="text-caption font-caption text-on-surface-variant mb-3">
                    {new Date(l.almarhum.tanggalKematian).toLocaleDateString("id-ID", {
                      day: "2-digit",
                      month: "short",
                      year: "numeric",
                    })}{" "}
                    &bull; Pelapor: {l.pelapor.nama}
                  </p>
                  <button
                    type="button"
                    onClick={() => setSelected(l)}
                    className="w-full border border-outline text-primary font-label-md text-label-md py-2 rounded-lg hover:bg-surface-container-high transition-all active:scale-[0.98] active:bg-surface-container-highest"
                  >
                    Lihat Detail
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>

      {selected && <LaporanDetailModal laporan={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
