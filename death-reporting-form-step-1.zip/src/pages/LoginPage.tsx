import { useState, type FormEvent } from "react";

interface Props {
  onLogin: (username: string) => void;
  onGoToRegister: () => void;
}

export default function LoginPage({ onLogin, onGoToRegister }: Props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError("Username dan password wajib diisi.");
      return;
    }
    setError(null);
    onLogin(username.trim());
  };

  return (
    <div className="min-h-screen bg-surface-container-low flex items-center justify-center p-container-padding-mobile md:p-container-padding-desktop">
      <main className="w-full max-w-md bg-surface-container-lowest border border-outline-variant rounded-xl shadow-sm overflow-hidden">
        <div className="p-stack-lg flex flex-col items-center border-b border-outline-variant bg-surface-bright">
          <div className="w-20 h-20 rounded-full bg-primary text-on-primary flex items-center justify-center mb-stack-md shadow-sm">
            <span className="material-symbols-outlined text-[40px]">shield_person</span>
          </div>
          <h1 className="text-headline-md font-headline-md text-primary mb-stack-sm text-center">PAKARTIGA</h1>
          <p className="text-body-md font-body-md text-on-surface-variant text-center">
            Pelaporan Kematian oleh RT ke Disdukcapil Kabupaten Garut
          </p>
        </div>

        <div className="p-stack-lg">
          <form onSubmit={handleSubmit} className="flex flex-col gap-gutter">
            {error && (
              <div className="flex items-start gap-2 bg-error-container text-on-error-container rounded-lg px-4 py-3">
                <span className="material-symbols-outlined text-[20px]">error</span>
                <p className="text-body-md font-body-md">{error}</p>
              </div>
            )}

            <div className="flex flex-col gap-stack-sm">
              <label className="text-label-md font-label-md text-on-surface" htmlFor="username">
                Username <span className="text-error">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-on-surface-variant">
                  <span className="material-symbols-outlined text-[20px]">person</span>
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Masukkan username Anda"
                  className="block w-full pl-10 pr-3 py-2 border border-outline-variant rounded-lg bg-surface text-body-md font-body-md text-on-surface focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-shadow"
                />
              </div>
            </div>

            <div className="flex flex-col gap-stack-sm">
              <label className="text-label-md font-label-md text-on-surface" htmlFor="password">
                Password <span className="text-error">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-on-surface-variant">
                  <span className="material-symbols-outlined text-[20px]">lock</span>
                </div>
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Masukkan password Anda"
                  className="block w-full pl-10 pr-10 py-2 border border-outline-variant rounded-lg bg-surface text-body-md font-body-md text-on-surface focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-shadow"
                />
                <button
                  type="button"
                  aria-label="Toggle password visibility"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-on-surface-variant hover:text-primary transition-colors focus:outline-none"
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {showPassword ? "visibility_off" : "visibility"}
                  </span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  className="h-4 w-4 text-primary focus:ring-primary border-outline-variant rounded bg-surface"
                />
                <label className="ml-2 block text-body-md font-body-md text-on-surface-variant" htmlFor="remember-me">
                  Ingat Saya
                </label>
              </div>
              <a className="text-label-md font-label-md text-primary hover:text-on-primary-fixed-variant transition-colors" href="#">
                Lupa Kata Sandi?
              </a>
            </div>

            <button
              type="submit"
              className="mt-stack-sm w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-label-md font-label-md text-on-primary bg-primary hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors"
            >
              Login
            </button>

            <div className="mt-stack-md text-center">
              <span className="text-body-md font-body-md text-on-surface-variant">Belum punya akun? </span>
              <button
                type="button"
                onClick={onGoToRegister}
                className="text-label-md font-label-md text-primary hover:text-on-primary-fixed-variant transition-colors"
              >
                Daftar
              </button>
            </div>
          </form>

          <div className="mt-stack-lg pt-stack-md border-t border-outline-variant text-center">
            <p className="text-caption font-caption text-outline">
              © 2026 Dinas Kependudukan dan Pencatatan Sipil.
              <br />
              Aplikasi Pemerintahan Resmi.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
