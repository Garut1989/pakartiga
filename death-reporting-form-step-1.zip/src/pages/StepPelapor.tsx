import { useState, type ReactNode } from "react";
import Stepper from "../components/Stepper";
import type { PelaporData } from "../types";

interface Props {
  data: PelaporData;
  onNext: (data: PelaporData) => void;
  onBack: () => void;
}

const HUBUNGAN_OPTIONS = [
  { value: "suami_istri", label: "Suami/Istri" },
  { value: "anak", label: "Anak" },
  { value: "orang_tua", label: "Orang Tua" },
  { value: "saudara", label: "Saudara" },
  { value: "lainnya", label: "Lainnya" },
];

export default function StepPelapor({ data, onNext, onBack }: Props) {
  const [form, setForm] = useState<PelaporData>(data);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = (key: keyof PelaporData, value: string) => setForm((f) => ({ ...f, [key]: value }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.hubungan) e.hubungan = "Pilih hubungan dengan almarhum.";
    if (!/^\d{16}$/.test(form.nik)) e.nik = "NIK harus terdiri dari 16 digit angka.";
    if (!form.nama.trim()) e.nama = "Nama lengkap wajib diisi.";
    if (!/^\d{8,13}$/.test(form.noHp)) e.noHp = "Masukkan nomor HP yang valid.";
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) e.email = "Format email tidak valid.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onNext(form);
  };

  return (
    <div className="w-full max-w-[600px] mx-auto">
      <Stepper step={2} stepLabel="Data Pelapor" />

      <div className="mb-stack-lg">
        <h2 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-md md:font-headline-md text-on-surface mb-stack-sm">
          Data Pelapor
        </h2>
        <p className="text-body-md font-body-md text-on-surface-variant">
          Silakan lengkapi informasi identitas Anda sebagai pihak yang melaporkan kejadian kematian.
        </p>
      </div>

      <div className="bg-surface-container-lowest rounded-xl border border-outline-variant shadow-sm p-6 mb-stack-lg">
        <form className="flex flex-col gap-gutter" onSubmit={(e) => e.preventDefault()}>
          <Field label="Hubungan dengan Almarhum" required error={errors.hubungan}>
            <div className="relative">
              <select
                className={inputClass(!!errors.hubungan) + " appearance-none pr-10"}
                value={form.hubungan}
                onChange={(e) => set("hubungan", e.target.value)}
              >
                <option value="" disabled>
                  Pilih hubungan
                </option>
                {HUBUNGAN_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
              <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-outline pointer-events-none">
                expand_more
              </span>
            </div>
          </Field>

          <Field
            label="Nomor Induk Kependudukan (NIK)"
            required
            error={errors.nik}
            hint="Pastikan NIK sesuai dengan KTP elektronik Anda."
          >
            <input
              className={inputClass(!!errors.nik)}
              maxLength={16}
              value={form.nik}
              onChange={(e) => set("nik", e.target.value.replace(/\D/g, ""))}
              placeholder="Masukkan 16 digit NIK"
              inputMode="numeric"
            />
          </Field>

          <Field label="Nama Lengkap" required error={errors.nama}>
            <input
              className={inputClass(!!errors.nama)}
              value={form.nama}
              onChange={(e) => set("nama", e.target.value)}
              placeholder="Nama lengkap sesuai KTP"
            />
          </Field>

          <Field label="Nomor Handphone (WhatsApp aktif)" required error={errors.noHp}>
            <div className="flex">
              <span className="inline-flex items-center px-4 rounded-l-lg border border-r-0 border-outline-variant bg-surface-container-high text-on-surface-variant text-body-md font-body-md">
                +62
              </span>
              <input
                className={inputClass(!!errors.noHp) + " rounded-l-none"}
                value={form.noHp}
                onChange={(e) => set("noHp", e.target.value.replace(/\D/g, ""))}
                placeholder="81234567890"
                inputMode="numeric"
                type="tel"
              />
            </div>
          </Field>

          <Field label="Alamat Email (Opsional)" error={errors.email}>
            <input
              className={inputClass(!!errors.email)}
              value={form.email}
              onChange={(e) => set("email", e.target.value)}
              placeholder="contoh@email.com"
              type="email"
            />
          </Field>
        </form>
      </div>

      <div className="flex flex-col-reverse md:flex-row gap-4 justify-between items-center">
        <button
          type="button"
          onClick={onBack}
          className="w-full md:w-auto px-6 py-3 rounded-full border border-secondary text-secondary text-label-md font-label-md hover:bg-surface-container-low transition-colors text-center"
        >
          Kembali
        </button>
        <button
          type="button"
          onClick={handleSubmit}
          className="w-full md:w-auto px-6 py-3 rounded-full bg-primary text-on-primary text-label-md font-label-md hover:opacity-90 transition-opacity text-center flex items-center justify-center gap-2 shadow-sm"
        >
          Lanjutkan <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>
    </div>
  );
}

function inputClass(hasError: boolean) {
  return (
    "w-full bg-surface border rounded-lg px-4 py-3 text-body-md font-body-md text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 transition-shadow " +
    (hasError
      ? "border-error focus:ring-error focus:border-error"
      : "border-outline-variant focus:ring-primary-fixed focus:border-primary")
  );
}

function Field({
  label,
  required,
  error,
  hint,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-stack-sm">
      <label className="text-label-md font-label-md text-on-surface flex items-center gap-1">
        {label} {required && <span className="text-error">*</span>}
      </label>
      {children}
      {error ? (
        <p className="text-caption font-caption text-error">{error}</p>
      ) : hint ? (
        <p className="text-caption font-caption text-on-surface-variant">{hint}</p>
      ) : null}
    </div>
  );
}
