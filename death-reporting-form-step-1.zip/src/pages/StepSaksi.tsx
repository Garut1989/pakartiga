import { useState } from "react";
import Stepper from "../components/Stepper";
import type { SaksiData } from "../types";

interface Props {
  data: SaksiData;
  onNext: (data: SaksiData) => void;
  onBack: () => void;
}

export default function StepSaksi({ data, onNext, onBack }: Props) {
  const [form, setForm] = useState<SaksiData>(data);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = (key: keyof SaksiData, value: string) => setForm((f) => ({ ...f, [key]: value }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!/^\d{16}$/.test(form.nikSaksi1)) e.nikSaksi1 = "NIK harus 16 digit angka.";
    if (!form.namaSaksi1.trim()) e.namaSaksi1 = "Nama saksi 1 wajib diisi.";
    if (!/^\d{16}$/.test(form.nikSaksi2)) e.nikSaksi2 = "NIK harus 16 digit angka.";
    if (!form.namaSaksi2.trim()) e.namaSaksi2 = "Nama saksi 2 wajib diisi.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onNext(form);
  };

  const inputClass = (hasError: boolean) =>
    "w-full px-4 py-3 bg-surface border rounded-lg focus:ring-2 transition-all text-body-md font-body-md " +
    (hasError
      ? "border-error focus:ring-error focus:border-error"
      : "border-outline-variant focus:ring-primary-fixed focus:border-primary");

  return (
    <div className="w-full max-w-[1000px] mx-auto">
      <Stepper step={3} stepLabel="Data Saksi" />

      <div className="mb-stack-lg">
        <h1 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-md md:font-headline-md text-on-surface mb-2">
          Data Saksi
        </h1>
        <p className="text-body-md font-body-md text-on-surface-variant">
          Lengkapi data dua orang saksi yang mengetahui kejadian kematian.
        </p>
      </div>

      <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-stack-lg shadow-sm">
        <form onSubmit={(e) => e.preventDefault()}>
          <div className="mb-stack-lg">
            <h2 className="text-title-lg font-title-lg text-on-surface mb-stack-md flex items-center">
              <span className="material-symbols-outlined mr-2 text-primary">person</span>
              Saksi 1
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              <div className="flex flex-col gap-stack-sm">
                <label className="text-label-md font-label-md text-on-surface">
                  NIK Saksi 1 <span className="text-error">*</span>
                </label>
                <input
                  className={inputClass(!!errors.nikSaksi1)}
                  maxLength={16}
                  value={form.nikSaksi1}
                  onChange={(e) => set("nikSaksi1", e.target.value.replace(/\D/g, ""))}
                  placeholder="Masukkan 16 digit NIK"
                  inputMode="numeric"
                />
                {errors.nikSaksi1 && <p className="text-caption font-caption text-error">{errors.nikSaksi1}</p>}
              </div>
              <div className="flex flex-col gap-stack-sm">
                <label className="text-label-md font-label-md text-on-surface">
                  Nama Lengkap Saksi 1 <span className="text-error">*</span>
                </label>
                <input
                  className={inputClass(!!errors.namaSaksi1)}
                  value={form.namaSaksi1}
                  onChange={(e) => set("namaSaksi1", e.target.value)}
                  placeholder="Sesuai KTP"
                />
                {errors.namaSaksi1 && <p className="text-caption font-caption text-error">{errors.namaSaksi1}</p>}
              </div>
            </div>
          </div>

          <hr className="border-t border-surface-container-highest mb-stack-lg" />

          <div className="mb-stack-lg">
            <h2 className="text-title-lg font-title-lg text-on-surface mb-stack-md flex items-center">
              <span className="material-symbols-outlined mr-2 text-primary">person</span>
              Saksi 2
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              <div className="flex flex-col gap-stack-sm">
                <label className="text-label-md font-label-md text-on-surface">
                  NIK Saksi 2 <span className="text-error">*</span>
                </label>
                <input
                  className={inputClass(!!errors.nikSaksi2)}
                  maxLength={16}
                  value={form.nikSaksi2}
                  onChange={(e) => set("nikSaksi2", e.target.value.replace(/\D/g, ""))}
                  placeholder="Masukkan 16 digit NIK"
                  inputMode="numeric"
                />
                {errors.nikSaksi2 && <p className="text-caption font-caption text-error">{errors.nikSaksi2}</p>}
              </div>
              <div className="flex flex-col gap-stack-sm">
                <label className="text-label-md font-label-md text-on-surface">
                  Nama Lengkap Saksi 2 <span className="text-error">*</span>
                </label>
                <input
                  className={inputClass(!!errors.namaSaksi2)}
                  value={form.namaSaksi2}
                  onChange={(e) => set("namaSaksi2", e.target.value)}
                  placeholder="Sesuai KTP"
                />
                {errors.namaSaksi2 && <p className="text-caption font-caption text-error">{errors.namaSaksi2}</p>}
              </div>
            </div>
          </div>

          <div className="flex flex-col-reverse md:flex-row justify-end gap-stack-md mt-stack-lg pt-stack-md border-t border-surface-container-highest">
            <button
              type="button"
              onClick={onBack}
              className="px-6 py-3 border border-secondary text-secondary font-label-md text-label-md rounded-full hover:bg-surface-container-low transition-colors w-full md:w-auto"
            >
              Kembali
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="px-6 py-3 bg-primary text-on-primary font-label-md text-label-md rounded-full hover:opacity-90 transition-colors flex justify-center items-center w-full md:w-auto shadow-sm"
            >
              Lanjutkan
              <span className="material-symbols-outlined ml-2 text-[18px]">arrow_forward</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
