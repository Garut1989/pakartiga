import { useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";

interface Props {
  onRegisterSuccess: () => void;
  onGoToLogin: () => void;
}

interface FormState {
  fullName: string;
  nik: string;
  role: string;
  kecamatan: string;
  desaKelurahan: string;
  phone: string;
  password: string;
  confirmPassword: string;
  selfieFileName: string | null;
}

const emptyForm: FormState = {
  fullName: "",
  nik: "",
  role: "",
  kecamatan: "",
  desaKelurahan: "",
  phone: "",
  password: "",
  confirmPassword: "",
  selfieFileName: null,
};

export default function RegisterPage({ onRegisterSuccess, onGoToLogin }: Props) {
  const [form, setForm] = useState<FormState>(emptyForm);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const handleFile = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    set("selfieFileName", file ? file.name : null);
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.fullName.trim()) e.fullName = "Nama lengkap wajib diisi.";
    if (!/^\d{16}$/.test(form.nik)) e.nik = "NIK harus terdiri dari 16 digit angka.";
    if (!form.role) e.role = "Pilih peran Anda.";
    if (!form.kecamatan) e.kecamatan = "Pilih kecamatan.";
    if (!form.desaKelurahan) e.desaKelurahan = "Pilih desa/kelurahan.";
    if (!/^\d{8,13}$/.test(form.phone)) e.phone = "Masukkan nomor telepon yang valid.";
    if (form.password.length < 6) e.password = "Password minimal 6 karakter.";
    if (form.confirmPassword !== form.password) e.confirmPassword = "Konfirmasi password tidak cocok.";
    if (!form.selfieFileName) e.selfie = "Unggah foto selfie dengan KTP.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onRegisterSuccess();
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-container-padding-mobile md:p-container-padding-desktop bg-[radial-gradient(at_0%_0%,#d5e3ff_0,transparent_50%),radial-gradient(at_100%_100%,#8cf3f3_0,transparent_50%)]">
      <main className="w-full max-w-[1200px] mx-auto flex flex-col md:flex-row items-center justify-center gap-12">
        {/* Left Side: Branding */}
        <section className="hidden md:flex flex-1 flex-col items-start gap-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary text-on-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[28px]">shield_person</span>
            </div>
            <h1 className="font-headline-lg text-headline-lg tracking-tight text-primary">PAKARTIGA</h1>
          </div>
          <div className="relative w-full aspect-square max-w-md rounded-xl overflow-hidden shadow-sm border border-outline-variant bg-surface-container-lowest flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-primary-fixed to-secondary-fixed opacity-60" />
            <span className="material-symbols-outlined text-[120px] text-primary relative z-10">account_balance</span>
          </div>
          <div className="space-y-2">
            <h2 className="font-headline-md text-headline-md text-on-background">Pelayanan Publik Terpadu</h2>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-sm">
              Mewujudkan transparansi dan kemudahan pelaporan data kependudukan secara digital dan akurat.
            </p>
          </div>
        </section>

        {/* Right Side: Registration Form */}
        <section className="w-full md:max-w-[480px] bg-surface-container-lowest p-8 md:p-10 rounded-xl border border-outline-variant shadow-sm">
          <div className="mb-8 text-center md:text-left">
            <div className="md:hidden flex items-center justify-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-full bg-primary text-on-primary flex items-center justify-center">
                <span className="material-symbols-outlined text-[22px]">shield_person</span>
              </div>
              <span className="font-headline-md text-headline-md font-bold text-primary">PAKARTIGA</span>
            </div>
            <h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface mb-2">
              Pendaftaran Akun
            </h1>
            <p className="font-body-md text-body-md text-on-surface-variant">
              Silakan lengkapi data diri Anda untuk mendaftar sebagai petugas.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <Field label="Nama Lengkap" required error={errors.fullName}>
              <div className="relative">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline">
                  person
                </span>
                <input
                  className={inputClass(!!errors.fullName) + " pl-10"}
                  value={form.fullName}
                  onChange={(e) => set("fullName", e.target.value)}
                  placeholder="Contoh: Budi Santoso"
                  type="text"
                />
              </div>
            </Field>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Field label="NIK (16 digit)" required error={errors.nik}>
                <input
                  className={inputClass(!!errors.nik)}
                  maxLength={16}
                  value={form.nik}
                  onChange={(e) => set("nik", e.target.value.replace(/\D/g, ""))}
                  placeholder="3201..."
                  inputMode="numeric"
                />
              </Field>
              <Field label="Peran" required error={errors.role}>
                <select
                  className={inputClass(!!errors.role) + " appearance-none"}
                  value={form.role}
                  onChange={(e) => set("role", e.target.value)}
                >
                  <option value="" disabled>
                    Pilih Peran
                  </option>
                  <option value="RT">RT</option>
                  <option value="Desa">Desa</option>
                  <option value="Disdukcapil">Disdukcapil</option>
                </select>
              </Field>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Field label="Kecamatan" required error={errors.kecamatan}>
                <select
                  className={inputClass(!!errors.kecamatan) + " appearance-none"}
                  value={form.kecamatan}
                  onChange={(e) => set("kecamatan", e.target.value)}
                >
                  <option value="" disabled>
                    Pilih Kecamatan
                  </option>
                  <option value="Tarogong Kidul">Tarogong Kidul</option>
                  <option value="Tarogong Kaler">Tarogong Kaler</option>
                  <option value="Garut Kota">Garut Kota</option>
                </select>
              </Field>
              <Field label="Desa/Kelurahan" required error={errors.desaKelurahan}>
                <select
                  className={inputClass(!!errors.desaKelurahan) + " appearance-none"}
                  value={form.desaKelurahan}
                  onChange={(e) => set("desaKelurahan", e.target.value)}
                >
                  <option value="" disabled>
                    Pilih Desa/Kelurahan
                  </option>
                  <option value="Sukagalih">Sukagalih</option>
                  <option value="Jayawaras">Jayawaras</option>
                  <option value="Sukakarya">Sukakarya</option>
                </select>
              </Field>
            </div>

            <Field label="Nomor Telepon/WhatsApp" required error={errors.phone}>
              <div className="relative">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline">
                  call
                </span>
                <input
                  className={inputClass(!!errors.phone) + " pl-10"}
                  value={form.phone}
                  onChange={(e) => set("phone", e.target.value.replace(/\D/g, ""))}
                  placeholder="0812..."
                  type="tel"
                  inputMode="numeric"
                />
              </div>
            </Field>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Field label="Password" required error={errors.password}>
                <div className="relative">
                  <input
                    className={inputClass(!!errors.password)}
                    value={form.password}
                    onChange={(e) => set("password", e.target.value)}
                    placeholder="••••••••"
                    type={showPassword ? "text" : "password"}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-primary"
                  >
                    <span className="material-symbols-outlined text-[20px]">
                      {showPassword ? "visibility_off" : "visibility"}
                    </span>
                  </button>
                </div>
              </Field>
              <Field label="Konfirmasi" required error={errors.confirmPassword}>
                <input
                  className={inputClass(!!errors.confirmPassword)}
                  value={form.confirmPassword}
                  onChange={(e) => set("confirmPassword", e.target.value)}
                  placeholder="••••••••"
                  type={showPassword ? "text" : "password"}
                />
              </Field>
            </div>

            <div className="space-y-2">
              <label className="font-label-md text-label-md text-on-surface flex items-center gap-1">
                Foto Selfie dengan KTP <span className="text-error">*</span>
              </label>
              <div
                className={
                  "relative border-2 border-dashed rounded-xl p-6 bg-surface-container-low hover:bg-surface-container transition-colors flex flex-col items-center justify-center gap-3 cursor-pointer " +
                  (errors.selfie ? "border-error" : "border-outline-variant")
                }
              >
                <input
                  type="file"
                  accept="image/*"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  onChange={handleFile}
                />
                <div className="w-12 h-12 rounded-full bg-primary-fixed flex items-center justify-center">
                  <span className="material-symbols-outlined text-primary text-[32px]">
                    {form.selfieFileName ? "check_circle" : "photo_camera"}
                  </span>
                </div>
                <div className="text-center">
                  <p className="font-label-md text-label-md text-primary">
                    {form.selfieFileName ?? "Unggah foto selfie memegang KTP asli"}
                  </p>
                  <p className="font-caption text-caption text-on-surface-variant mt-1">untuk verifikasi wajah</p>
                </div>
              </div>
              {errors.selfie && <p className="text-caption font-caption text-error">{errors.selfie}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-primary text-on-primary hover:opacity-90 transition-colors duration-200 rounded-lg font-label-md text-label-md flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]"
            >
              Daftar
              <span className="material-symbols-outlined">app_registration</span>
            </button>
          </form>

          <div className="mt-8 text-center pt-6 border-t border-outline-variant">
            <p className="font-body-md text-body-md text-on-surface-variant">
              Sudah punya akun?{" "}
              <button type="button" onClick={onGoToLogin} className="text-secondary font-bold hover:underline">
                Login
              </button>
            </p>
          </div>
        </section>
      </main>
    </div>
  );
}

function inputClass(hasError: boolean) {
  return (
    "w-full px-4 py-3 rounded-lg border bg-surface focus:ring-1 outline-none transition-all font-body-md text-body-md " +
    (hasError
      ? "border-error focus:border-error focus:ring-error"
      : "border-outline-variant focus:border-primary focus:ring-primary")
  );
}

function Field({
  label,
  required,
  error,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-2">
      <label className="font-label-md text-label-md text-on-surface flex items-center gap-1">
        {label} {required && <span className="text-error">*</span>}
      </label>
      {children}
      {error && <p className="text-caption font-caption text-error">{error}</p>}
    </div>
  );
}
