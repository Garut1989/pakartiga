import { useMemo, useState } from "react";
import type { Laporan, LaporanStatus } from "../types";

interface Props {
  laporanList: Laporan[];
  onNewLaporan: () => void;
}

const STATUS_FILTERS: (LaporanStatus | "Semua Status")[] = [
  "Semua Status",
  "Baru",
  "Pengajuan",
  "Proses",
  "Ditolak",
  "Selesai",
];

const STATUS_STYLE: Record<LaporanStatus, string> = {
  Baru: "bg-primary-fixed text-on-primary-fixed-variant",
  Pengajuan: "bg-secondary-container text-on-secondary-container",
  Proses: "bg-tertiary-fixed text-on-tertiary-fixed-variant",
  Ditolak: "bg-error-container text-on-error-container",
  Selesai: "bg-secondary-fixed text-on-secondary-fixed-variant",
};

export default function Dashboard({ laporanList, onNewLaporan }: Props) {
  const [filter, setFilter] = useState<(typeof STATUS_FILTERS)[number]>("Semua Status");

  const filtered = useMemo(
    () => (filter === "Semua Status" ? laporanList : laporanList.filter((l) => l.status === filter)),
    [laporanList, filter]
  );

  const counts = useMemo(() => {
    const c: Record<string, number> = { Total: laporanList.length };
    for (const status of ["Baru", "Pengajuan", "Proses", "Selesai"] as LaporanStatus[]) {
      c[status] = laporanList.filter((l) => l.status === status).length;
    }
    return c;
  }, [laporanList]);

  return (
    <div>
      <div className="mb-stack-lg mt-stack-md">
        <h1 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-lg md:font-headline-lg text-on-surface mb-1">
          Beranda Petugas
        </h1>
        <p className="text-body-md font-body-md text-on-surface-variant">
          Kelola dan pantau pengajuan laporan kematian warga RT 03 / RW 05.
        </p>
      </div>

      <div className="mb-stack-lg">
        <button
          type="button"
          onClick={onNewLaporan}
          className="w-full md:w-auto bg-primary text-on-primary font-label-md text-label-md py-3 px-6 rounded-full hover:opacity-90 transition-all shadow-sm flex justify-center items-center gap-2 animate-pulse-gentle active:scale-95"
        >
          <span className="material-symbols-outlined icon-fill">add_circle</span>
          Buat Pengajuan Baru
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-gutter mb-stack-lg">
        <SummaryCard label="Total Laporan" value={counts.Total} icon="folder_copy" color="text-primary" bg="bg-primary-fixed" />
        <SummaryCard label="Baru" value={counts.Baru} icon="fiber_new" color="text-on-primary-fixed-variant" bg="bg-primary-fixed" />
        <SummaryCard label="Diproses" value={counts.Proses} icon="hourglass_top" color="text-on-tertiary-fixed-variant" bg="bg-tertiary-fixed" />
        <SummaryCard label="Selesai" value={counts.Selesai} icon="task_alt" color="text-on-secondary-fixed-variant" bg="bg-secondary-fixed" />
      </div>

      {/* Filter */}
      <div className="mb-stack-md">
        <div className="flex gap-2 items-center">
          <div className="relative flex-grow max-w-xs">
            <span className="absolute -top-2 left-3 bg-background px-1 text-caption font-label-md text-primary z-10">
              Status Pengajuan
            </span>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as (typeof STATUS_FILTERS)[number])}
              className="w-full border-2 border-primary rounded-xl py-3 px-4 text-on-surface bg-surface-container-lowest focus:ring-0 focus:border-primary appearance-none font-body-md"
            >
              {STATUS_FILTERS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
              <span className="material-symbols-outlined text-outline">expand_more</span>
            </div>
          </div>
        </div>
      </div>

      {/* Reports List */}
      <div className="flex flex-col gap-stack-md mb-stack-lg">
        {filtered.length === 0 ? (
          <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-10 text-center text-on-surface-variant">
            <span className="material-symbols-outlined text-[40px] mb-2 block">inbox</span>
            Tidak ada laporan dengan status ini.
          </div>
        ) : (
          filtered.map((l) => (
            <div
              key={l.id}
              className="bg-surface-container-lowest border border-outline-variant rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-outline transition-colors"
            >
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-full bg-surface-container-highest flex items-center justify-center text-on-surface-variant flex-shrink-0">
                  <span className="material-symbols-outlined">description</span>
                </div>
                <div>
                  <p className="text-label-md font-label-md text-on-surface">{l.almarhum.namaLengkap}</p>
                  <p className="text-caption font-caption text-on-surface-variant">
                    Pelapor: {l.pelapor.nama} &middot; {l.createdAt}
                  </p>
                  <p className="text-caption font-caption text-outline mt-0.5">No. Tiket: {l.id}</p>
                </div>
              </div>
              <span
                className={`self-start sm:self-center text-caption font-label-md px-3 py-1 rounded-full ${STATUS_STYLE[l.status]}`}
              >
                {l.status}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function SummaryCard({
  label,
  value,
  icon,
  color,
  bg,
}: {
  label: string;
  value: number;
  icon: string;
  color: string;
  bg: string;
}) {
  return (
    <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-4 flex flex-col gap-3">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${bg} ${color}`}>
        <span className="material-symbols-outlined">{icon}</span>
      </div>
      <div>
        <p className="text-headline-md font-headline-md text-on-surface">{value}</p>
        <p className="text-caption font-caption text-on-surface-variant">{label}</p>
      </div>
    </div>
  );
}
