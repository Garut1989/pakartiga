interface Props {
  reportId: string;
  onBackToDashboard: () => void;
}

export default function SuccessPage({ reportId, onBackToDashboard }: Props) {
  return (
    <div className="w-full max-w-[600px] mx-auto flex flex-col items-center text-center py-12">
      <div className="w-24 h-24 rounded-full bg-secondary-container flex items-center justify-center mb-stack-lg animate-bounce-subtle">
        <span className="material-symbols-outlined text-[56px] text-on-secondary-container icon-fill">
          check_circle
        </span>
      </div>
      <h1 className="text-headline-lg-mobile font-headline-lg-mobile md:text-headline-lg md:font-headline-lg text-on-surface mb-stack-sm">
        Laporan Berhasil Dikirim
      </h1>
      <p className="text-body-md font-body-md text-on-surface-variant mb-stack-lg">
        Terima kasih. Laporan kematian Anda telah kami terima dan akan diverifikasi oleh petugas RT. Anda dapat
        memantau status pengajuan pada halaman Beranda.
      </p>
      <div className="bg-surface-container-lowest border border-outline-variant rounded-xl px-6 py-4 mb-stack-lg w-full">
        <p className="text-caption font-caption text-on-surface-variant mb-1">Nomor Tiket Laporan</p>
        <p className="text-title-lg font-title-lg text-primary tracking-wide">{reportId}</p>
      </div>
      <button
        type="button"
        onClick={onBackToDashboard}
        className="w-full sm:w-auto bg-primary text-on-primary text-label-md font-label-md px-8 py-3 rounded-full flex items-center justify-center gap-2 hover:opacity-90 transition-colors shadow-sm"
      >
        <span className="material-symbols-outlined text-[18px]">home</span>
        Kembali ke Beranda
      </button>
    </div>
  );
}
