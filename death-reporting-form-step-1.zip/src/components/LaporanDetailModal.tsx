import type { Laporan } from "../types";

interface Props {
  laporan: Laporan;
  onClose: () => void;
}

const HUBUNGAN_LABEL: Record<string, string> = {
  suami_istri: "Suami/Istri",
  anak: "Anak",
  orang_tua: "Orang Tua",
  saudara: "Saudara",
  lainnya: "Lainnya",
};

function formatTanggal(tanggal: string) {
  if (!tanggal) return "-";
  try {
    return new Date(tanggal).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
  } catch {
    return tanggal;
  }
}

export default function LaporanDetailModal({ laporan, onClose }: Props) {
  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-inverse-surface/40" onClick={onClose} />
      <div className="relative bg-surface-container-lowest rounded-t-xl sm:rounded-xl w-full sm:max-w-2xl max-h-[90vh] overflow-y-auto shadow-lg">
        <div className="sticky top-0 bg-surface-container-lowest border-b border-outline-variant px-6 py-4 flex items-center justify-between z-10">
          <div>
            <h2 className="text-title-lg font-title-lg text-on-surface">Detail Laporan</h2>
            <p className="text-caption font-caption text-on-surface-variant">No. Tiket: {laporan.id}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-full hover:bg-surface-container-high text-on-surface-variant"
            aria-label="Tutup"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="p-6 flex flex-col gap-gutter">
          <section>
            <h3 className="text-label-md font-label-md text-primary mb-stack-sm flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">personal_injury</span>
              Data Almarhum
            </h3>
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-y-stack-sm gap-x-6 bg-surface-container-low rounded-lg p-4">
              <Item label="NIK" value={laporan.almarhum.nik} />
              <Item label="Nama Lengkap" value={laporan.almarhum.namaLengkap} />
              <Item label="Tanggal Wafat" value={formatTanggal(laporan.almarhum.tanggalKematian)} />
              <Item label="Waktu Wafat" value={laporan.almarhum.waktuKematian ? `${laporan.almarhum.waktuKematian} WIB` : "-"} />
              <Item label="Tempat Wafat" value={laporan.almarhum.tempatKematian} span2 />
              <Item label="Tempat Pemakaman" value={laporan.almarhum.tempatPemakaman} span2 />
            </dl>
          </section>

          <section>
            <h3 className="text-label-md font-label-md text-primary mb-stack-sm flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">record_voice_over</span>
              Data Pelapor
            </h3>
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-y-stack-sm gap-x-6 bg-surface-container-low rounded-lg p-4">
              <Item label="NIK" value={laporan.pelapor.nik} />
              <Item label="Nama Lengkap" value={laporan.pelapor.nama} />
              <Item label="Hubungan" value={HUBUNGAN_LABEL[laporan.pelapor.hubungan] ?? "-"} />
              <Item label="No. HP" value={laporan.pelapor.noHp ? `+62 ${laporan.pelapor.noHp}` : "-"} />
            </dl>
          </section>

          <section>
            <h3 className="text-label-md font-label-md text-primary mb-stack-sm flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">group</span>
              Data Saksi
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <dl className="bg-surface-container-low rounded-lg p-4 flex flex-col gap-2">
                <p className="text-caption font-caption text-on-surface-variant">Saksi I</p>
                <Item label="NIK" value={laporan.saksi.nikSaksi1 || "-"} />
                <Item label="Nama" value={laporan.saksi.namaSaksi1 || "-"} />
              </dl>
              <dl className="bg-surface-container-low rounded-lg p-4 flex flex-col gap-2">
                <p className="text-caption font-caption text-on-surface-variant">Saksi II</p>
                <Item label="NIK" value={laporan.saksi.nikSaksi2 || "-"} />
                <Item label="Nama" value={laporan.saksi.namaSaksi2 || "-"} />
              </dl>
            </div>
          </section>

          <section>
            <h3 className="text-label-md font-label-md text-primary mb-stack-sm flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">folder_open</span>
              Dokumen
            </h3>
            <ul className="bg-surface-container-low rounded-lg p-4 flex flex-col gap-3">
              {laporan.dokumen.map((d) => (
                <li key={d.key} className="flex items-center gap-3">
                  <span
                    className={"material-symbols-outlined " + (d.fileName ? "text-secondary" : "text-outline")}
                  >
                    {d.fileName ? "check_circle" : "radio_button_unchecked"}
                  </span>
                  <div>
                    <p className="text-label-md font-label-md text-on-surface">{d.label}</p>
                    <p className="text-caption font-caption text-on-surface-variant">
                      {d.fileName ?? (d.required ? "Belum diunggah" : "Opsional")}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        </div>

        <div className="px-6 py-4 border-t border-outline-variant flex justify-end sticky bottom-0 bg-surface-container-lowest">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-full bg-primary text-on-primary text-label-md font-label-md hover:opacity-90 transition-opacity"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
}

function Item({ label, value, span2 }: { label: string; value: string; span2?: boolean }) {
  return (
    <div className={span2 ? "sm:col-span-2" : ""}>
      <dt className="text-caption font-caption text-on-surface-variant">{label}</dt>
      <dd className="text-body-md font-body-md text-on-surface">{value}</dd>
    </div>
  );
}
