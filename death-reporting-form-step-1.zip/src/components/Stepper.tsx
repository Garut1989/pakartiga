interface StepperProps {
  step: 1 | 2 | 3 | 4 | 5;
  stepLabel: string;
}

const STEPS = [
  { n: 1, label: "Almarhum" },
  { n: 2, label: "Pelapor" },
  { n: 3, label: "Saksi" },
  { n: 4, label: "Dokumen" },
  { n: 5, label: "Konfirmasi" },
];

export default function Stepper({ step, stepLabel }: StepperProps) {
  const progress = (step / 5) * 100;

  return (
    <div className="mb-stack-lg">
      {/* Mobile Progress */}
      <div className="md:hidden mb-stack-md">
        <div className="flex justify-between items-center mb-stack-sm">
          <span className="text-label-md font-label-md text-on-surface-variant">
            Langkah {step} dari 5
          </span>
          <span className="text-label-md font-label-md text-primary font-bold">{stepLabel}</span>
        </div>
        <div className="w-full bg-surface-container-highest rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-primary h-1.5 rounded-full transition-all duration-500 ease-in-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Desktop Stepper */}
      <div className="hidden md:flex justify-between items-center relative">
        <div className="absolute left-0 top-4 w-full h-0.5 bg-surface-container-highest -z-10" />
        <div
          className="absolute left-0 top-4 h-0.5 bg-primary -z-10 transition-all duration-500"
          style={{ width: `${((step - 1) / 4) * 100}%` }}
        />
        {STEPS.map((s) => {
          const isDone = s.n < step;
          const isActive = s.n === step;
          return (
            <div key={s.n} className="flex flex-col items-center gap-2 bg-background px-1">
              <div
                className={
                  "w-8 h-8 rounded-full flex items-center justify-center text-label-md font-label-md shadow-sm transition-colors " +
                  (isDone
                    ? "bg-primary text-on-primary"
                    : isActive
                    ? "bg-primary text-on-primary ring-4 ring-primary-fixed"
                    : "bg-surface-container-highest text-on-surface-variant")
                }
              >
                {isDone ? <span className="material-symbols-outlined text-[16px]">check</span> : s.n}
              </div>
              <span
                className={
                  "text-caption font-caption " +
                  (isActive ? "text-primary font-bold" : "text-on-surface-variant")
                }
              >
                {s.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
