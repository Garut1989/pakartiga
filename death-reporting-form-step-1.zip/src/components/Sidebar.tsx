interface SidebarProps {
  active: "beranda" | "laporan" | "profil";
  onNavigate: (target: "beranda" | "laporan" | "profil") => void;
}

export default function Sidebar({ active, onNavigate }: SidebarProps) {
  const items = [
    { key: "beranda", label: "Beranda", icon: "home" },
    { key: "laporan", label: "Laporan", icon: "description" },
    { key: "profil", label: "Profil", icon: "person" },
  ] as const;

  return (
    <nav className="hidden md:flex flex-col fixed left-0 top-16 h-[calc(100vh-4rem)] w-72 bg-surface border-r border-outline-variant z-40 pt-8 overflow-y-auto">
      <div className="px-6 mb-8 flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-primary-container text-on-primary flex items-center justify-center font-bold text-lg shadow-inner">
          RT
        </div>
        <div>
          <h2 className="font-title-lg text-title-lg text-primary">Petugas Pelayanan</h2>
          <p className="text-on-surface-variant text-caption font-caption">RT 03 / RW 05</p>
        </div>
      </div>
      <div className="flex flex-col gap-1 px-4">
        {items.map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => onNavigate(item.key)}
            className={
              "flex items-center gap-4 px-4 py-3 mx-2 my-1 rounded-full transition-all text-left w-[calc(100%-1rem)] " +
              (active === item.key
                ? "bg-secondary-container text-on-secondary-container font-bold"
                : "text-on-surface-variant hover:bg-surface-container-highest hover:translate-x-1")
            }
          >
            <span className="material-symbols-outlined">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
