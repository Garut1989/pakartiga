interface BottomNavProps {
  active: "beranda" | "pengajuan" | "laporan" | "profil";
  onNewLaporan: () => void;
  onNavigate: (target: "beranda" | "laporan" | "profil") => void;
}

export default function BottomNav({ active, onNewLaporan, onNavigate }: BottomNavProps) {
  const linkClass = (key: string) =>
    "flex flex-col items-center justify-center transition-all px-4 py-1.5 active:scale-90 " +
    (active === key ? "text-primary" : "text-on-surface-variant hover:text-primary");

  return (
    <nav className="md:hidden bg-surface-container-lowest border-t border-outline-variant shadow-sm fixed bottom-0 left-0 w-full z-50 flex justify-around items-center py-2 px-2">
      <button type="button" className={linkClass("beranda")} onClick={() => onNavigate("beranda")}>
        <span className="material-symbols-outlined text-[24px]">home</span>
        <span className="text-[10px] font-label-md">Beranda</span>
      </button>
      <button type="button" onClick={onNewLaporan} className="flex flex-col items-center justify-center transition-all">
        <div className="bg-primary-container text-on-primary rounded-full px-5 py-1 flex items-center justify-center">
          <span className="material-symbols-outlined text-[24px] icon-fill">add_box</span>
        </div>
        <span className="text-[10px] font-label-md text-on-surface font-bold mt-0.5">Pengajuan</span>
      </button>
      <button type="button" className={linkClass("laporan")} onClick={() => onNavigate("laporan")}>
        <span className="material-symbols-outlined text-[24px]">assignment</span>
        <span className="text-[10px] font-label-md">Laporan</span>
      </button>
      <button type="button" className={linkClass("profil")} onClick={() => onNavigate("profil")}>
        <span className="material-symbols-outlined text-[24px]">account_circle</span>
        <span className="text-[10px] font-label-md">Profil</span>
      </button>
    </nav>
  );
}
