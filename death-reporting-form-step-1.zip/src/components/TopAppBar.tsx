interface TopAppBarProps {
  variant: "dashboard" | "transactional";
  title?: string;
  onBack?: () => void;
  onMenuClick?: () => void;
  onProfileClick?: () => void;
}

export default function TopAppBar({ variant, title, onBack, onMenuClick, onProfileClick }: TopAppBarProps) {
  return (
    <header className="fixed top-0 left-0 w-full h-16 bg-surface border-b border-outline-variant flex items-center justify-between px-container-padding-mobile md:px-container-padding-desktop z-50">
      <div className="flex items-center gap-4">
        {variant === "transactional" ? (
          <button
            aria-label="Kembali"
            onClick={onBack}
            className="text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high transition-colors p-2 -ml-2 rounded-full flex items-center justify-center"
            type="button"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
        ) : (
          <button
            aria-label="Menu"
            onClick={onMenuClick}
            className="md:hidden text-primary hover:bg-surface-container-high transition-colors p-2 rounded-full active:scale-95"
            type="button"
          >
            <span className="material-symbols-outlined">menu</span>
          </button>
        )}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-sm">
            P
          </div>
          <span className="text-title-lg font-title-lg font-bold text-primary tracking-tight">
            {variant === "transactional" ? title ?? "PAKARTIGA" : "PAKARTIGA"}
          </span>
        </div>
      </div>
      {variant === "dashboard" && (
        <div className="flex items-center">
          <button
            type="button"
            onClick={onProfileClick}
            className="w-8 h-8 rounded-full bg-surface-container-highest flex items-center justify-center text-on-surface-variant hover:ring-2 ring-primary transition-all"
            aria-label="Profil"
          >
            <span className="material-symbols-outlined text-[20px]">person</span>
          </button>
        </div>
      )}
    </header>
  );
}
