import { useState } from "react";
import TopAppBar from "./components/TopAppBar";
import Sidebar from "./components/Sidebar";
import BottomNav from "./components/BottomNav";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import Dashboard from "./pages/Dashboard";
import LaporanPage from "./pages/LaporanPage";
import ProfilePage from "./pages/ProfilePage";
import StepAlmarhum from "./pages/StepAlmarhum";
import StepPelapor from "./pages/StepPelapor";
import StepSaksi from "./pages/StepSaksi";
import StepDokumen from "./pages/StepDokumen";
import StepKonfirmasi from "./pages/StepKonfirmasi";
import SuccessPage from "./pages/SuccessPage";
import {
  emptyAlmarhum,
  emptyPelapor,
  emptySaksi,
  DOKUMEN_LIST,
  type AlmarhumData,
  type PelaporData,
  type SaksiData,
  type DokumenItem,
  type Laporan,
  type WizardStep,
  type AppView,
} from "./types";

const SEED_LAPORAN: Laporan[] = [
  {
    id: "PKT-2026-0012",
    almarhum: {
      nik: "3273162508850004",
      namaLengkap: "Budi Santoso bin Kartono",
      tanggalKematian: "2026-01-12",
      waktuKematian: "14:30",
      tempatKematian: "RSUD Hasan Sadikin, Bandung",
      tempatPemakaman: "TPU Pasir Pogor",
    },
    pelapor: {
      hubungan: "anak",
      nik: "3273161011900002",
      nama: "Siti Aminah",
      noHp: "81234567890",
      email: "siti.aminah@email.com",
    },
    saksi: {
      nikSaksi1: "3273160505800007",
      namaSaksi1: "Agus Setiawan",
      nikSaksi2: "3273161212850003",
      namaSaksi2: "Rina Mulyani",
    },
    dokumen: DOKUMEN_LIST.map((d) => ({ ...d, fileName: d.required ? `${d.key}.pdf` : null })),
    status: "Proses",
    createdAt: "18 Jan 2026",
    createdAtISO: "2026-01-18",
  },
  {
    id: "PKT-2026-0011",
    almarhum: {
      nik: "3273165005900001",
      namaLengkap: "Hj. Maryam Wulandari",
      tanggalKematian: "2026-01-05",
      waktuKematian: "05:10",
      tempatKematian: "Kabupaten Garut",
      tempatPemakaman: "TPU Cikuray",
    },
    pelapor: {
      hubungan: "suami_istri",
      nik: "3273165005850009",
      nama: "Iwan Setiawan",
      noHp: "85211122233",
      email: "",
    },
    saksi: {
      nikSaksi1: "3273165005850010",
      namaSaksi1: "Dedi Kurniawan",
      nikSaksi2: "3273165005850011",
      namaSaksi2: "Yani Suryani",
    },
    dokumen: DOKUMEN_LIST.map((d) => ({ ...d, fileName: d.required ? `${d.key}.jpg` : null })),
    status: "Selesai",
    createdAt: "07 Jan 2026",
    createdAtISO: "2026-01-07",
  },
  {
    id: "PKT-2026-0013",
    almarhum: {
      nik: "3273169903990005",
      namaLengkap: "Ahmad Zulkifli",
      tanggalKematian: "2026-01-20",
      waktuKematian: "20:45",
      tempatKematian: "Kota Bandung",
      tempatPemakaman: "TPU Sirnaraga",
    },
    pelapor: {
      hubungan: "anak",
      nik: "3273169903990006",
      nama: "Fajar Nugraha",
      noHp: "89988776655",
      email: "fajar.n@email.com",
    },
    saksi: emptySaksi,
    dokumen: DOKUMEN_LIST,
    status: "Baru",
    createdAt: "21 Jan 2026",
    createdAtISO: "2026-01-21",
  },
  {
    id: "PKT-2026-0010",
    almarhum: {
      nik: "3273163103880002",
      namaLengkap: "Aminah Supriyadi",
      tanggalKematian: "2026-01-08",
      waktuKematian: "09:15",
      tempatKematian: "Kota Bandung",
      tempatPemakaman: "TPU Cikadut",
    },
    pelapor: {
      hubungan: "anak",
      nik: "3273163103880003",
      nama: "Ahmad Yani",
      noHp: "81122334455",
      email: "",
    },
    saksi: {
      nikSaksi1: "3273163103880004",
      namaSaksi1: "Bambang Hartono",
      nikSaksi2: "3273163103880005",
      namaSaksi2: "Sri Wahyuni",
    },
    dokumen: DOKUMEN_LIST.map((d) => ({ ...d, fileName: d.required ? `${d.key}.pdf` : null })),
    status: "Ditolak",
    createdAt: "09 Jan 2026",
    createdAtISO: "2026-01-09",
  },
];

export default function App() {
  const [view, setView] = useState<AppView>("login");
  const [step, setStep] = useState<WizardStep>(1);
  const [laporanList, setLaporanList] = useState<Laporan[]>(SEED_LAPORAN);
  const [petugasName, setPetugasName] = useState<string>("Bambang Hermanto");

  const [almarhum, setAlmarhum] = useState<AlmarhumData>(emptyAlmarhum);
  const [pelapor, setPelapor] = useState<PelaporData>(emptyPelapor);
  const [saksi, setSaksi] = useState<SaksiData>(emptySaksi);
  const [dokumen, setDokumen] = useState<DokumenItem[]>(DOKUMEN_LIST.map((d) => ({ ...d })));
  const [lastReportId, setLastReportId] = useState<string>("");

  const resetForm = () => {
    setAlmarhum(emptyAlmarhum);
    setPelapor(emptyPelapor);
    setSaksi(emptySaksi);
    setDokumen(DOKUMEN_LIST.map((d) => ({ ...d })));
  };

  const startNewLaporan = () => {
    resetForm();
    setStep(1);
    setView("wizard");
  };

  const goBackToDashboard = () => {
    setView("dashboard");
  };

  const navigate = (target: "beranda" | "laporan" | "profil") => {
    if (target === "beranda") setView("dashboard");
    else if (target === "laporan") setView("laporan");
    else setView("profil");
  };

  const handleLogin = (username: string) => {
    const displayName = username
      .split(/[.\s_]+/)
      .filter(Boolean)
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(" ");
    setPetugasName(displayName || "Petugas RT");
    setView("dashboard");
  };

  const handleLogout = () => {
    setView("login");
  };

  const handleSubmitLaporan = () => {
    const id = `PKT-2026-${String(laporanList.length + 1).padStart(4, "0")}`;
    const now = new Date();
    const newLaporan: Laporan = {
      id,
      almarhum,
      pelapor,
      saksi,
      dokumen,
      status: "Baru",
      createdAt: now.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }),
      createdAtISO: now.toISOString().slice(0, 10),
    };
    setLaporanList((prev) => [newLaporan, ...prev]);
    setLastReportId(id);
    setView("success");
  };

  const stepTitles: Record<WizardStep, string> = {
    1: "Data Almarhum",
    2: "Data Pelapor",
    3: "Data Saksi",
    4: "Upload Dokumen",
    5: "Konfirmasi",
  };

  return (
    <div className="min-h-screen bg-background text-on-background">
      {view === "login" && (
        <LoginPage onLogin={handleLogin} onGoToRegister={() => setView("register")} />
      )}

      {view === "register" && (
        <RegisterPage onRegisterSuccess={() => setView("login")} onGoToLogin={() => setView("login")} />
      )}

      {view === "dashboard" && (
        <>
          <TopAppBar variant="dashboard" onProfileClick={() => navigate("profil")} />
          <Sidebar active="beranda" onNavigate={navigate} />
          <main className="pt-16 pb-24 md:pb-12 md:ml-72 px-container-padding-mobile md:px-container-padding-desktop max-w-[1200px] mx-auto">
            <Dashboard laporanList={laporanList} onNewLaporan={startNewLaporan} />
          </main>
          <BottomNav active="beranda" onNewLaporan={startNewLaporan} onNavigate={navigate} />
        </>
      )}

      {view === "laporan" && (
        <>
          <TopAppBar variant="dashboard" onProfileClick={() => navigate("profil")} />
          <Sidebar active="laporan" onNavigate={navigate} />
          <main className="pt-16 pb-24 md:pb-12 md:ml-72 px-container-padding-mobile md:px-container-padding-desktop max-w-[1200px] mx-auto">
            <LaporanPage laporanList={laporanList} />
          </main>
          <BottomNav active="laporan" onNewLaporan={startNewLaporan} onNavigate={navigate} />
        </>
      )}

      {view === "profil" && (
        <>
          <TopAppBar variant="transactional" title="Profil" onBack={goBackToDashboard} />
          <Sidebar active="profil" onNavigate={navigate} />
          <main className="pt-20 pb-24 md:pb-12 md:ml-72 px-container-padding-mobile md:px-container-padding-desktop max-w-[1200px] mx-auto">
            <ProfilePage name={petugasName} onLogout={handleLogout} />
          </main>
          <BottomNav active="profil" onNewLaporan={startNewLaporan} onNavigate={navigate} />
        </>
      )}

      {view === "wizard" && (
        <>
          <TopAppBar
            variant="transactional"
            title={stepTitles[step]}
            onBack={() => {
              if (step === 1) {
                goBackToDashboard();
              } else {
                setStep((s) => (s - 1) as WizardStep);
              }
            }}
          />
          <main className="pt-24 pb-16 px-container-padding-mobile md:px-container-padding-desktop">
            {step === 1 && (
              <StepAlmarhum
                data={almarhum}
                onNext={(data) => {
                  setAlmarhum(data);
                  setStep(2);
                }}
                onBack={goBackToDashboard}
              />
            )}
            {step === 2 && (
              <StepPelapor
                data={pelapor}
                onNext={(data) => {
                  setPelapor(data);
                  setStep(3);
                }}
                onBack={() => setStep(1)}
              />
            )}
            {step === 3 && (
              <StepSaksi
                data={saksi}
                onNext={(data) => {
                  setSaksi(data);
                  setStep(4);
                }}
                onBack={() => setStep(2)}
              />
            )}
            {step === 4 && (
              <StepDokumen
                data={dokumen}
                onNext={(data) => {
                  setDokumen(data);
                  setStep(5);
                }}
                onBack={() => setStep(3)}
              />
            )}
            {step === 5 && (
              <StepKonfirmasi
                almarhum={almarhum}
                pelapor={pelapor}
                saksi={saksi}
                dokumen={dokumen}
                onSubmit={handleSubmitLaporan}
                onBack={() => setStep(4)}
                onEditStep={(s) => setStep(s)}
              />
            )}
          </main>
        </>
      )}

      {view === "success" && (
        <>
          <TopAppBar variant="dashboard" />
          <main className="pt-16 px-container-padding-mobile md:px-container-padding-desktop max-w-[1200px] mx-auto min-h-screen flex items-center">
            <SuccessPage reportId={lastReportId} onBackToDashboard={goBackToDashboard} />
          </main>
        </>
      )}
    </div>
  );
}
